# Дополнительные задания
## Добавьте другие компоненты со страницы (https://reactjs.org/) 

> Добавил компонент, использующий внешний плагин Remarkable, который преобразует введённый Markdown текст

#### Подключение компонента в `index.html`:

```
<script src="https://cdnjs.cloudflare.com/ajax/libs/remarkable/1.7.1/remarkable.js"></script>
```
