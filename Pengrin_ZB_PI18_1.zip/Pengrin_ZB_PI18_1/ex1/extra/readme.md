# Дополнительные задания
### Дополнительно: попробовать React с JSX

Для ознакомления с JSX использовал [документацию](https://ru.reactjs.org/docs/introducing-jsx.html "Знакомство с JSX")

В **index.html** добавил скрипт:

`<script src="https://unpkg.com/@babel/standalone/babel.min.js"></script>`